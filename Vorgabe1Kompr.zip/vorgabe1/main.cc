/* $Id$ */
#include <bootloader/bootloader_info.h>
#include <machine/efifb.h>
#include <object/fb.h>
#include <machine/efiscr.h>

/* TODO: Hier muesst ihr selbst Code vervollstaendigen */

extern BootloaderInfo *bootloader_info;
        
int main()
{

  EFI_Framebuffer EFI_fb;
  
  Framebuffer fb(bootloader_info->horizontal_resolution, bootloader_info->vertical_resolution);

  // for (unsigned int y = 0; y < fb.get_height(); y++)
  // {
  //     for (unsigned int x = 0; x < fb.get_width(); x++)
  //     {
  //         unsigned int value = 0x000000;
  //         fb.set_pixel(x, y, Pixel(value));
  //     }
  // }

  EFI_Screen EFI_sc;

  EFI_sc.show(0, 0, 'A', Pixel(0xffffff), Pixel(0x000000));
 
  return 0;
}
