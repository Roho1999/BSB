/*****************************************************************************/
/* Betriebssysteme                                                           */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                         A P P L I C A T I O N                             */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Die Klasse Application definiert die einzige Anwendung von OO-Stubs.      */
/*****************************************************************************/

/* INCLUDES */

#include "user/appl.h"
#include "device/efistr.h"
         
/* GLOBALE VARIABLEN */

extern EFI_Stream kout;
         
void Application::action ()
 {
/* TODO: Hier muesst ihr selbst Code vervollstaendigen */ 
 
 }
